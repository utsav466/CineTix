"use client";

import {
  Banknote,
  BarChart3,
  CheckCircle2,
  Ticket,
} from "lucide-react";

import {
  useEffect,
  useState,
} from "react";

import {
  getAdminDashboard,
} from "@/lib/api/dashboard.api";

import {
  getApiErrorMessage,
} from "@/lib/api/client";

import type {
  AdminDashboardData,
} from "@/lib/api/dashboard.types";

const emptyData:
  AdminDashboardData = {
    metrics: {
      totalUsers: 0,
      totalMovies: 0,
      totalCinemas: 0,
      totalShowtimes: 0,
      totalBookings: 0,
      confirmedBookings: 0,
      pendingBookings: 0,
      totalRevenue: 0,
    },

    recentBookings: [],
  };

export default function AdminReportsPage() {
  const [data, setData] =
    useState<AdminDashboardData>(
      emptyData,
    );

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  useEffect(() => {
    async function loadReport() {
      try {
        setData(
          await getAdminDashboard(),
        );
      } catch (loadError) {
        setError(
          getApiErrorMessage(
            loadError,
            "Unable to load report.",
          ),
        );
      } finally {
        setLoading(false);
      }
    }

    void loadReport();
  }, []);

  const confirmationRate =
    data.metrics.totalBookings >
    0
      ? Math.round(
          (
            data.metrics
              .confirmedBookings /
            data.metrics
              .totalBookings
          ) *
            100,
        )
      : 0;

  const averageBookingValue =
    data.metrics
      .confirmedBookings > 0
      ? Math.round(
          data.metrics
            .totalRevenue /
            data.metrics
              .confirmedBookings,
        )
      : 0;

  const cards = [
    {
      label:
        "Total Revenue",

      value: `NPR ${data.metrics.totalRevenue.toLocaleString(
        "en-US",
      )}`,

      icon:
        Banknote,
    },
    {
      label:
        "Confirmed Bookings",

      value:
        data.metrics.confirmedBookings.toLocaleString(
          "en-US",
        ),

      icon:
        CheckCircle2,
    },
    {
      label:
        "Confirmation Rate",

      value:
        `${confirmationRate}%`,

      icon:
        BarChart3,
    },
    {
      label:
        "Average Booking Value",

      value: `NPR ${averageBookingValue.toLocaleString(
        "en-US",
      )}`,

      icon:
        Ticket,
    },
  ];

  return (
    <section>
      <p className="text-sm font-bold uppercase tracking-[0.22em] text-red-500">
        Analytics
      </p>

      <h1 className="mt-2 text-3xl font-black md:text-4xl">
        Reports
      </h1>

      <p className="mt-2 text-white/45">
        Review high-level booking and
        revenue performance.
      </p>

      {error && (
        <div className="mt-6 rounded-xl border border-red-500/20 bg-red-500/10 p-4 text-red-300">
          {error}
        </div>
      )}

      <div className="mt-8 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map(
          (card) => {
            const Icon =
              card.icon;

            return (
              <article
                key={card.label}
                className="rounded-2xl border border-white/10 bg-[#11141c] p-6"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-red-500/10 text-red-400">
                  <Icon size={21} />
                </div>

                <p className="mt-5 text-sm text-white/45">
                  {card.label}
                </p>

                <p className="mt-2 text-2xl font-black">
                  {loading
                    ? "—"
                    : card.value}
                </p>
              </article>
            );
          },
        )}
      </div>

      <section className="mt-8 rounded-2xl border border-white/10 bg-[#11141c] p-6">
        <h2 className="text-xl font-black">
          Booking Performance
        </h2>

        <div className="mt-6">
          <div className="flex justify-between text-sm">
            <span className="text-white/50">
              Confirmed booking rate
            </span>

            <span className="font-bold">
              {confirmationRate}%
            </span>
          </div>

          <div className="mt-3 h-3 overflow-hidden rounded-full bg-white/5">
            <div
              className="h-full rounded-full bg-red-600 transition-all"
              style={{
                width:
                  `${confirmationRate}%`,
              }}
            />
          </div>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <div className="rounded-xl bg-white/[0.03] p-5">
            <p className="text-sm text-white/40">
              Total bookings
            </p>

            <p className="mt-2 text-xl font-black">
              {
                data.metrics
                  .totalBookings
              }
            </p>
          </div>

          <div className="rounded-xl bg-white/[0.03] p-5">
            <p className="text-sm text-white/40">
              Confirmed
            </p>

            <p className="mt-2 text-xl font-black text-green-400">
              {
                data.metrics
                  .confirmedBookings
              }
            </p>
          </div>

          <div className="rounded-xl bg-white/[0.03] p-5">
            <p className="text-sm text-white/40">
              Pending
            </p>

            <p className="mt-2 text-xl font-black text-amber-400">
              {
                data.metrics
                  .pendingBookings
              }
            </p>
          </div>
        </div>
      </section>
    </section>
  );
}