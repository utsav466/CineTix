"use client";

import {
  Search,
  SlidersHorizontal,
  X,
} from "lucide-react";

import {
  useEffect,
  useMemo,
  useState,
} from "react";

import CustomerHeader from "@/components/layout/CustomerHeader";

import CustomerMovieCard from "@/components/movies/CustomerMovieCard";

import {
  getCustomerMovies,
} from "@/lib/api/customer.api";

import {
  getApiErrorMessage,
} from "@/lib/api/client";

import type {
  CustomerMovie,
} from "@/lib/api/customer.types";

export default function MoviesPage() {
  const [
    movies,
    setMovies,
  ] =
    useState<CustomerMovie[]>(
      [],
    );

  const [search, setSearch] =
    useState("");

  const [status, setStatus] =
    useState("");

  const [language, setLanguage] =
    useState("");

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  useEffect(() => {
    async function loadMovies() {
      try {
        setLoading(true);
        setError("");

        setMovies(
          await getCustomerMovies({
            limit: 100,
          }),
        );
      } catch (loadError) {
        setError(
          getApiErrorMessage(
            loadError,
            "Unable to load movies.",
          ),
        );
      } finally {
        setLoading(false);
      }
    }

    void loadMovies();
  }, []);

  const languages =
    useMemo(
      () =>
        Array.from(
          new Set(
            movies
              .map(
                (movie) =>
                  movie.language,
              )
              .filter(
                (
                  value,
                ): value is string =>
                  Boolean(value),
              ),
          ),
        ).sort(),
      [movies],
    );

  const filteredMovies =
    useMemo(
      () =>
        movies.filter(
          (movie) => {
            const normalizedSearch =
              search
                .trim()
                .toLowerCase();

            const matchesSearch =
              !normalizedSearch ||
              movie.title
                .toLowerCase()
                .includes(
                  normalizedSearch,
                );

            const matchesStatus =
              !status ||
              movie.status ===
                status;

            const matchesLanguage =
              !language ||
              movie.language ===
                language;

            return (
              matchesSearch &&
              matchesStatus &&
              matchesLanguage
            );
          },
        ),
      [
        movies,
        search,
        status,
        language,
      ],
    );

  const activeFilterCount =
    [
      search,
      status,
      language,
    ].filter(Boolean).length;

  function clearFilters() {
    setSearch("");
    setStatus("");
    setLanguage("");
  }

  return (
    <main className="min-h-screen bg-[#07080c] text-white">
      <CustomerHeader />

      <section className="mx-auto max-w-7xl px-5 py-12">
        <div className="max-w-2xl">
          <p className="text-sm font-bold uppercase tracking-[0.22em] text-red-500">
            Discover
          </p>

          <h1 className="mt-2 text-4xl font-black md:text-5xl">
            Movies
          </h1>

          <p className="mt-3 leading-7 text-white/50">
            Find a film quickly using
            only the filters that matter
            most.
          </p>
        </div>

        <section
          aria-label="Movie filters"
          className="mt-8 rounded-2xl border border-white/10 bg-[#11141c] p-4"
        >
          <div className="grid gap-3 lg:grid-cols-[1fr_220px_220px_auto]">
            <label className="relative">
              <span className="sr-only">
                Search movies
              </span>

              <Search
                size={18}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-white/35"
              />

              <input
                value={search}
                onChange={(event) =>
                  setSearch(
                    event.target.value,
                  )
                }
                placeholder="Search by movie title"
                className="min-h-12 w-full rounded-xl border border-white/10 bg-[#090b10] py-3 pl-11 pr-4 outline-none transition focus:border-red-500"
              />
            </label>

            <label>
              <span className="sr-only">
                Filter by status
              </span>

              <select
                value={status}
                onChange={(event) =>
                  setStatus(
                    event.target.value,
                  )
                }
                className="min-h-12 w-full rounded-xl border border-white/10 bg-[#090b10] px-4 outline-none focus:border-red-500"
              >
                <option value="">
                  All availability
                </option>

                <option value="now_showing">
                  Now showing
                </option>

                <option value="coming_soon">
                  Coming soon
                </option>
              </select>
            </label>

            <label>
              <span className="sr-only">
                Filter by language
              </span>

              <select
                value={language}
                onChange={(event) =>
                  setLanguage(
                    event.target.value,
                  )
                }
                className="min-h-12 w-full rounded-xl border border-white/10 bg-[#090b10] px-4 outline-none focus:border-red-500"
              >
                <option value="">
                  All languages
                </option>

                {languages.map(
                  (item) => (
                    <option
                      key={item}
                      value={item}
                    >
                      {item}
                    </option>
                  ),
                )}
              </select>
            </label>

            <button
              type="button"
              onClick={
                clearFilters
              }
              disabled={
                activeFilterCount ===
                0
              }
              className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl border border-white/10 px-4 font-bold text-white/60 transition hover:bg-white/5 disabled:cursor-not-allowed disabled:opacity-35"
            >
              <X size={17} />

              Clear
            </button>
          </div>

          <div className="mt-4 flex items-center justify-between text-sm text-white/40">
            <span className="inline-flex items-center gap-2">
              <SlidersHorizontal
                size={16}
              />

              {activeFilterCount} active
              filters
            </span>

            <span>
              {
                filteredMovies.length
              }{" "}
              results
            </span>
          </div>
        </section>

        {error && (
          <div className="mt-6 rounded-xl border border-red-500/20 bg-red-500/10 p-4 text-red-300">
            {error}
          </div>
        )}

        {loading ? (
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({
              length: 8,
            }).map(
              (_, index) => (
                <div
                  key={index}
                  className="aspect-[2/3] animate-pulse rounded-2xl bg-white/5"
                />
              ),
            )}
          </div>
        ) : filteredMovies.length ===
          0 ? (
          <div className="mt-8 rounded-2xl border border-white/10 bg-[#11141c] p-10 text-center">
            <h2 className="text-xl font-bold">
              No matching movies
            </h2>

            <p className="mt-2 text-white/45">
              Clear a filter or try a
              different movie title.
            </p>

            <button
              type="button"
              onClick={
                clearFilters
              }
              className="mt-6 min-h-11 rounded-xl bg-red-600 px-5 font-bold hover:bg-red-500"
            >
              Clear filters
            </button>
          </div>
        ) : (
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {filteredMovies.map(
              (movie) => (
                <CustomerMovieCard
                  key={movie.id}
                  movie={movie}
                />
              ),
            )}
          </div>
        )}
      </section>
    </main>
  );
}