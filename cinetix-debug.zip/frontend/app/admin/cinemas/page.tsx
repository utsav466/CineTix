"use client";

import {
  FormEvent,
  useEffect,
  useState,
} from "react";

import {
  Building2,
  Plus,
  Trash2,
} from "lucide-react";

import {
  createCinema,
  deleteCinema,
  getCinemas,
} from "@/lib/api/cinemas.api";

import {
  getApiErrorMessage,
} from "@/lib/api/client";

import type {
  Cinema,
  CinemaInput,
} from "@/lib/api/cinemas.types";

const initialForm: CinemaInput = {
  name: "",
  city: "",
  address: "",
  phone: "",
  description: "",
  facilities: [],
  imageUrl: "",
  isActive: true,
};

export default function AdminCinemasPage() {
  const [cinemas, setCinemas] =
    useState<Cinema[]>([]);

  const [form, setForm] =
    useState<CinemaInput>(
      initialForm,
    );

  const [
    facilitiesText,
    setFacilitiesText,
  ] =
    useState("");

  const [loading, setLoading] =
    useState(true);

  const [
    submitting,
    setSubmitting,
  ] =
    useState(false);

  const [error, setError] =
    useState("");

  async function loadCinemas() {
    try {
      setLoading(true);
      setError("");

      setCinemas(
        await getCinemas(),
      );
    } catch (loadError) {
      setError(
        getApiErrorMessage(
          loadError,
          "Unable to load cinemas",
        ),
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadCinemas();
  }, []);

  async function handleSubmit(
    event: FormEvent,
  ) {
    event.preventDefault();

    try {
      setSubmitting(true);
      setError("");

      await createCinema({
        ...form,

        facilities:
          facilitiesText
            .split(",")
            .map((item) =>
              item.trim(),
            )
            .filter(Boolean),
      });

      setForm(initialForm);
      setFacilitiesText("");

      await loadCinemas();
    } catch (submitError) {
      setError(
        getApiErrorMessage(
          submitError,
          "Unable to create cinema",
        ),
      );
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(
    cinema: Cinema,
  ) {
    if (
      !window.confirm(
        `Delete ${cinema.name}?`,
      )
    ) {
      return;
    }

    try {
      await deleteCinema(
        cinema.id,
      );

      await loadCinemas();
    } catch (deleteError) {
      setError(
        getApiErrorMessage(
          deleteError,
          "Unable to delete cinema",
        ),
      );
    }
  }

  const inputClass =
    "mt-2 w-full rounded-xl border border-white/10 bg-[#090b10] px-4 py-3 outline-none focus:border-red-500";

  return (
    <section>
      <p className="text-sm font-semibold uppercase tracking-[0.22em] text-red-500">
        Venue management
      </p>

      <h1 className="mt-2 text-3xl font-bold">
        Cinemas
      </h1>

      <p className="mt-2 text-white/55">
        Add cinema branches before
        creating their halls and seat
        layouts.
      </p>

      {error && (
        <div className="mt-6 rounded-xl border border-red-500/20 bg-red-500/10 p-4 text-red-300">
          {error}
        </div>
      )}

      <div className="mt-8 grid gap-6 xl:grid-cols-[420px_1fr]">
        <form
          onSubmit={(event) => {
            void handleSubmit(event);
          }}
          className="h-fit rounded-2xl border border-white/10 bg-[#11141c] p-6"
        >
          <h2 className="text-lg font-semibold">
            Add Cinema
          </h2>

          <label className="mt-5 block">
            <span className="text-sm text-white/60">
              Cinema name
            </span>

            <input
              required
              value={form.name}
              onChange={(event) =>
                setForm({
                  ...form,
                  name:
                    event.target.value,
                })
              }
              className={inputClass}
            />
          </label>

          <label className="mt-4 block">
            <span className="text-sm text-white/60">
              City
            </span>

            <input
              required
              value={form.city}
              onChange={(event) =>
                setForm({
                  ...form,
                  city:
                    event.target.value,
                })
              }
              className={inputClass}
            />
          </label>

          <label className="mt-4 block">
            <span className="text-sm text-white/60">
              Address
            </span>

            <input
              required
              value={form.address}
              onChange={(event) =>
                setForm({
                  ...form,
                  address:
                    event.target.value,
                })
              }
              className={inputClass}
            />
          </label>

          <label className="mt-4 block">
            <span className="text-sm text-white/60">
              Phone
            </span>

            <input
              value={form.phone}
              onChange={(event) =>
                setForm({
                  ...form,
                  phone:
                    event.target.value,
                })
              }
              className={inputClass}
            />
          </label>

          <label className="mt-4 block">
            <span className="text-sm text-white/60">
              Facilities
            </span>

            <input
              value={
                facilitiesText
              }
              onChange={(event) =>
                setFacilitiesText(
                  event.target.value,
                )
              }
              placeholder="Parking, Dolby Atmos, Café"
              className={inputClass}
            />
          </label>

          <button
            type="submit"
            disabled={submitting}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-red-600 px-5 py-3 font-semibold hover:bg-red-500 disabled:opacity-60"
          >
            <Plus size={18} />

            {submitting
              ? "Adding..."
              : "Add Cinema"}
          </button>
        </form>

        <div className="rounded-2xl border border-white/10 bg-[#11141c]">
          {loading ? (
            <p className="p-8 text-white/50">
              Loading cinemas...
            </p>
          ) : cinemas.length === 0 ? (
            <p className="p-8 text-white/50">
              No cinemas added yet.
            </p>
          ) : (
            <div className="divide-y divide-white/10">
              {cinemas.map(
                (cinema) => (
                  <article
                    key={cinema.id}
                    className="flex items-center justify-between gap-5 p-5"
                  >
                    <div className="flex items-center gap-4">
                      <div className="rounded-xl bg-red-500/10 p-3 text-red-400">
                        <Building2 size={22} />
                      </div>

                      <div>
                        <h3 className="font-semibold">
                          {
                            cinema.name
                          }
                        </h3>

                        <p className="mt-1 text-sm text-white/45">
                          {cinema.city} ·{" "}
                          {
                            cinema.address
                          }
                        </p>

                        <p className="mt-1 text-xs text-white/35">
                          {
                            cinema.hallCount ||
                            0
                          }{" "}
                          halls
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        void handleDelete(
                          cinema,
                        );
                      }}
                      className="rounded-lg bg-red-500/10 p-2 text-red-400 hover:bg-red-500/20"
                    >
                      <Trash2 size={17} />
                    </button>
                  </article>
                ),
              )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}