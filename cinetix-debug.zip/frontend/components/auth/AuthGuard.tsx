"use client";

import {
  ReactNode,
  useEffect,
  useState,
} from "react";

import {
  usePathname,
  useRouter,
} from "next/navigation";

import {
  getCurrentUser,
} from "@/lib/api/auth.api";

import type {
  AuthUser,
  UserRole,
} from "@/lib/api/auth.types";
import { clearAuthSession, getAuthToken } from "@/lib/api/auth-storage";



type AuthGuardProps = {
  children: ReactNode;
  requiredRole?: UserRole;
};

export default function AuthGuard({
  children,
  requiredRole,
}: AuthGuardProps) {
  const router = useRouter();
  const pathname = usePathname();

  const [user, setUser] =
    useState<AuthUser | null>(null);

  const [isChecking, setIsChecking] =
    useState(true);

  useEffect(() => {
    async function verifySession() {
      const token = getAuthToken();

      if (!token) {
        router.replace(
          `/login?redirect=${encodeURIComponent(
            pathname,
          )}`,
        );

        return;
      }

      try {
        const currentUser =
          await getCurrentUser();

        if (
          requiredRole &&
          currentUser.role !==
            requiredRole
        ) {
          router.replace("/");
          return;
        }

        setUser(currentUser);
      } catch {
        clearAuthSession();

        router.replace(
          `/login?redirect=${encodeURIComponent(
            pathname,
          )}`,
        );
      } finally {
        setIsChecking(false);
      }
    }

    void verifySession();
  }, [
    pathname,
    requiredRole,
    router,
  ]);

  if (isChecking) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#07080c] text-white">
        <div className="text-center">
          <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-white/20 border-t-red-500" />

          <p className="mt-4 text-sm text-white/70">
            Checking your CineTix session...
          </p>
        </div>
      </main>
    );
  }

  if (!user) {
    return null;
  }

  return children;
}