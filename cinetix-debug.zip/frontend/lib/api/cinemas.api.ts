import {
  apiClient,
} from "./client";

import type {
  Cinema,
  CinemaInput,
  Screen,
  ScreenInput,
} from "./cinemas.types";

type CinemaListResponse = {
  success: true;
  data: {
    items: Cinema[];
  };
};

type CinemaResponse = {
  success: true;
  data: {
    cinema: Cinema;
  };
};

type ScreenListResponse = {
  success: true;
  data: {
    items: Screen[];
  };
};

type ScreenResponse = {
  success: true;
  data: {
    screen: Screen;
  };
};

export async function getCinemas(
  search = "",
): Promise<Cinema[]> {
  const response =
    await apiClient.get<CinemaListResponse>(
      "/cinemas",
      {
        params: {
          search:
            search || undefined,
        },
      },
    );

  return response.data.data.items;
}

export async function createCinema(
  payload: CinemaInput,
): Promise<Cinema> {
  const response =
    await apiClient.post<CinemaResponse>(
      "/cinemas",
      payload,
    );

  return response.data.data.cinema;
}

export async function updateCinema(
  id: string,
  payload: Partial<CinemaInput>,
): Promise<Cinema> {
  const response =
    await apiClient.patch<CinemaResponse>(
      `/cinemas/${id}`,
      payload,
    );

  return response.data.data.cinema;
}

export async function deleteCinema(
  id: string,
): Promise<void> {
  await apiClient.delete(
    `/cinemas/${id}`,
  );
}

export async function getScreens(
  cinemaId?: string,
): Promise<Screen[]> {
  const response =
    await apiClient.get<ScreenListResponse>(
      "/screens",
      {
        params: {
          cinemaId,
        },
      },
    );

  return response.data.data.items;
}

export async function getScreen(
  id: string,
): Promise<Screen> {
  const response =
    await apiClient.get<ScreenResponse>(
      `/screens/${id}`,
    );

  return response.data.data.screen;
}

export async function createScreen(
  payload: ScreenInput,
): Promise<Screen> {
  const response =
    await apiClient.post<ScreenResponse>(
      "/screens",
      payload,
    );

  return response.data.data.screen;
}

export async function updateScreen(
  id: string,
  payload: Partial<ScreenInput>,
): Promise<Screen> {
  const response =
    await apiClient.patch<ScreenResponse>(
      `/screens/${id}`,
      payload,
    );

  return response.data.data.screen;
}

export async function deleteScreen(
  id: string,
): Promise<void> {
  await apiClient.delete(
    `/screens/${id}`,
  );
}