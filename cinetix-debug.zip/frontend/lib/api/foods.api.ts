import {
  apiClient,
} from "./client";

import type {
  Food,
  FoodCategory,
  FoodInput,
} from "./foods.types";

type FoodListResponse = {
  success: true;

  data: {
    items: Food[];
  };
};

type FoodResponse = {
  success: true;
  message?: string;

  data: {
    food: Food;
  };
};

export async function getFoods(
  params?: {
    search?: string;
    category?: FoodCategory | "";
    available?: boolean;
  },
): Promise<Food[]> {
  const response =
    await apiClient.get<FoodListResponse>(
      "/foods",
      {
        params,
      },
    );

  return response.data.data.items;
}

export async function getFood(
  foodId: string,
): Promise<Food> {
  const response =
    await apiClient.get<FoodResponse>(
      `/foods/${foodId}`,
    );

  return response.data.data.food;
}

export async function createFood(
  payload: FoodInput,
): Promise<Food> {
  const response =
    await apiClient.post<FoodResponse>(
      "/foods",
      payload,
    );

  return response.data.data.food;
}

export async function updateFood(
  foodId: string,
  payload: Partial<FoodInput>,
): Promise<Food> {
  const response =
    await apiClient.patch<FoodResponse>(
      `/foods/${foodId}`,
      payload,
    );

  return response.data.data.food;
}

export async function deleteFood(
  foodId: string,
): Promise<void> {
  await apiClient.delete(
    `/foods/${foodId}`,
  );
}