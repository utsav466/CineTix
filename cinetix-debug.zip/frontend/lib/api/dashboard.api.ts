import {
  apiClient,
} from "./client";

import type {
  AdminBooking,
  AdminDashboardData,
  AdminDashboardMetrics,
  AdminUser,
} from "./dashboard.types";

type UnknownRecord =
  Record<string, unknown>;

function isRecord(
  value: unknown,
): value is UnknownRecord {
  return (
    typeof value === "object" &&
    value !== null
  );
}

function numberValue(
  value: unknown,
): number {
  return typeof value ===
    "number"
    ? value
    : 0;
}

const emptyMetrics:
  AdminDashboardMetrics = {
    totalUsers: 0,
    totalMovies: 0,
    totalCinemas: 0,
    totalShowtimes: 0,
    totalBookings: 0,
    confirmedBookings: 0,
    pendingBookings: 0,
    totalRevenue: 0,
  };

export async function getAdminDashboard():
  Promise<AdminDashboardData> {
  const response =
    await apiClient.get(
      "/admin/dashboard",
    );

  const root =
    response.data;

  const data =
    isRecord(root) &&
    isRecord(root.data)
      ? root.data
      : {};

  const metricsSource =
    isRecord(data.metrics)
      ? data.metrics
      : data;

  const recentBookings =
    Array.isArray(
      data.recentBookings,
    )
      ? (
          data.recentBookings as
            AdminDashboardData["recentBookings"]
        )
      : [];

  return {
    metrics: {
      totalUsers:
        numberValue(
          metricsSource.totalUsers,
        ),

      totalMovies:
        numberValue(
          metricsSource.totalMovies,
        ),

      totalCinemas:
        numberValue(
          metricsSource.totalCinemas,
        ),

      totalShowtimes:
        numberValue(
          metricsSource.totalShowtimes,
        ),

      totalBookings:
        numberValue(
          metricsSource.totalBookings,
        ),

      confirmedBookings:
        numberValue(
          metricsSource.confirmedBookings,
        ),

      pendingBookings:
        numberValue(
          metricsSource.pendingBookings,
        ),

      totalRevenue:
        numberValue(
          metricsSource.totalRevenue,
        ),
    },

    recentBookings,
  };
}

export async function getAdminBookings():
  Promise<AdminBooking[]> {
  const response =
    await apiClient.get(
      "/admin/bookings",
    );

  const root =
    response.data;

  if (
    isRecord(root) &&
    isRecord(root.data)
  ) {
    if (
      Array.isArray(
        root.data.items,
      )
    ) {
      return root.data
        .items as AdminBooking[];
    }

    if (
      Array.isArray(
        root.data.bookings,
      )
    ) {
      return root.data
        .bookings as AdminBooking[];
    }
  }

  return [];
}

export async function getAdminUsers():
  Promise<AdminUser[]> {
  const response =
    await apiClient.get(
      "/admin/users",
    );

  const root =
    response.data;

  if (
    isRecord(root) &&
    isRecord(root.data)
  ) {
    if (
      Array.isArray(
        root.data.items,
      )
    ) {
      return root.data
        .items as AdminUser[];
    }

    if (
      Array.isArray(
        root.data.users,
      )
    ) {
      return root.data
        .users as AdminUser[];
    }
  }

  return [];
}