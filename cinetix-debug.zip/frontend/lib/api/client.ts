import axios from "axios";

const apiBaseUrl =
  process.env
    .NEXT_PUBLIC_API_URL ||
  "http://localhost:5001/api";

export const apiClient =
  axios.create({
    baseURL:
      apiBaseUrl,

    withCredentials:
      true,

    timeout:
      15000,

    headers: {
      Accept:
        "application/json",

      "Content-Type":
        "application/json",
    },
  });

type ApiErrorResponse = {
  message?: string;
  error?: string;

  errors?: Array<{
    message?: string;
  }>;
};

export function getApiErrorMessage(
  error: unknown,
  fallback =
    "Something went wrong.",
): string {
  if (
    axios.isAxiosError(
      error,
    )
  ) {
    if (
      error.code ===
      "ECONNABORTED"
    ) {
      return "The request took too long. Please try again.";
    }

    if (!error.response) {
      return "Unable to connect to the CineTix server.";
    }

    const data =
      error.response
        .data as
        | ApiErrorResponse
        | undefined;

    if (
      typeof data?.message ===
        "string" &&
      data.message.trim()
    ) {
      return data.message;
    }

    if (
      typeof data?.error ===
        "string" &&
      data.error.trim()
    ) {
      return data.error;
    }

    const validationMessage =
      data?.errors?.[0]
        ?.message;

    if (
      validationMessage
    ) {
      return validationMessage;
    }

    if (
      error.response
        .status === 401
    ) {
      return "Incorrect email or password.";
    }

    if (
      error.response
        .status === 409
    ) {
      return "An account with this email already exists.";
    }

    if (
      error.response
        .status >= 500
    ) {
      return "The CineTix server encountered an error.";
    }
  }

  if (
    error instanceof Error &&
    error.message
  ) {
    return error.message;
  }

  return fallback;
}