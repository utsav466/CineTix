import {
  apiClient,
} from "./client";

import type {
  CustomerBooking,
  CustomerCinema,
  CustomerMovie,
  CustomerShowtime,
} from "./customer.types";

type MovieListResponse = {
  success: true;

  data: {
    items: CustomerMovie[];
    total?: number;
    page?: number;
    limit?: number;
  };
};

type MovieResponse = {
  success: true;

  data: {
    movie: CustomerMovie;
  };
};

type ShowtimeListResponse = {
  success: true;

  data: {
    items: CustomerShowtime[];
  };
};

type CinemaListResponse = {
  success: true;

  data: {
    items: CustomerCinema[];
  };
};

type BookingListResponse = {
  success: true;

  data: {
    items: CustomerBooking[];
  };
};

export async function getCustomerMovies(
  params?: {
    search?: string;
    status?: string;
    page?: number;
    limit?: number;
  },
): Promise<CustomerMovie[]> {
  const response =
    await apiClient.get<MovieListResponse>(
      "/movies",
      {
        params,
      },
    );

  return response.data.data.items;
}

export async function getCustomerMovie(
  movieId: string,
): Promise<CustomerMovie> {
  const response =
    await apiClient.get<MovieResponse>(
      `/movies/${movieId}`,
    );

  return response.data.data.movie;
}

export async function getCustomerShowtimes(
  params?: {
    movieId?: string;
    cinemaId?: string;
    date?: string;
  },
): Promise<CustomerShowtime[]> {
  const response =
    await apiClient.get<ShowtimeListResponse>(
      "/showtimes",
      {
        params,
      },
    );

  return response.data.data.items;
}

export async function getCustomerCinemas():
  Promise<CustomerCinema[]> {
  const response =
    await apiClient.get<CinemaListResponse>(
      "/cinemas",
    );

  return response.data.data.items;
}

export async function getCustomerBookings():
  Promise<CustomerBooking[]> {
  const response =
    await apiClient.get<BookingListResponse>(
      "/bookings/my",
    );

  return response.data.data.items;
}