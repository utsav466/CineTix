import bcryptjs from "bcryptjs";
import jwt, {
  SignOptions,
} from "jsonwebtoken";

import { env } from "../config";

import {
  CreateUserInput,
  LoginUserInput,
} from "../dtos/user.dto";

import { HttpError } from "../errors/http-error";

import {
  IUser,
} from "../models/user.model";

import {
  UserRepository,
} from "../repositories/user.repository";

const userRepository =
  new UserRepository();

export type PublicUser = {
  id: string;
  fullName: string;
  email: string;
  username: string;
  phone?: string;
  role: "user" | "admin";
  preferredCurrency:
    | "NPR"
    | "USD"
    | "INR";
  avatarUrl: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
};

function createUsernameFromEmail(
  email: string,
): string {
  const emailPrefix =
    email.split("@")[0] || "user";

  const safePrefix = emailPrefix
    .toLowerCase()
    .replace(
      /[^a-z0-9._-]/g,
      "",
    )
    .slice(0, 20);

  const randomSuffix = Math.floor(
    1000 + Math.random() * 9000,
  );

  return `${
    safePrefix || "user"
  }${randomSuffix}`;
}

export function toPublicUser(
  user: IUser,
): PublicUser {
  return {
    id: user._id.toString(),
    fullName: user.fullName,
    email: user.email,
    username: user.username,
    phone: user.phone,
    role: user.role,
    preferredCurrency:
      user.preferredCurrency,
    avatarUrl: user.avatarUrl || "",
    isActive: user.isActive,
    createdAt: user.createdAt,
    updatedAt: user.updatedAt,
  };
}

export class UserService {
  private createToken(
    user: IUser,
  ): string {
    const payload = {
      userId: user._id.toString(),
      role: user.role,
    };

    const options: SignOptions = {
      expiresIn:
        env.jwtExpiresIn as SignOptions["expiresIn"],
      issuer: "cinetix-api",
      audience: "cinetix-client",
    };

    return jwt.sign(
      payload,
      env.jwtSecret,
      options,
    );
  }

  private async createUniqueUsername(
    email: string,
    requestedUsername?: string,
  ): Promise<string> {
    if (requestedUsername) {
      const normalizedUsername =
        requestedUsername
          .trim()
          .toLowerCase();

      const existingUsername =
        await userRepository.getUserByUsername(
          normalizedUsername,
        );

      if (existingUsername) {
        throw new HttpError(
          409,
          "Username is already in use",
        );
      }

      return normalizedUsername;
    }

    let generatedUsername =
      createUsernameFromEmail(email);

    while (
      await userRepository.getUserByUsername(
        generatedUsername,
      )
    ) {
      generatedUsername =
        createUsernameFromEmail(email);
    }

    return generatedUsername;
  }

  async createUser(
    data: CreateUserInput,
  ): Promise<{
    user: PublicUser;
    token: string;
  }> {
    const normalizedEmail =
      data.email.trim().toLowerCase();

    const existingEmail =
      await userRepository.getUserByEmail(
        normalizedEmail,
      );

    if (existingEmail) {
      throw new HttpError(
        409,
        "An account with this email already exists",
      );
    }

    const username =
      await this.createUniqueUsername(
        normalizedEmail,
        data.username,
      );

    const hashedPassword =
      await bcryptjs.hash(
        data.password,
        12,
      );

    const createdUser =
      await userRepository.createUser({
        fullName: data.fullName.trim(),
        email: normalizedEmail,
        username,
        phone: data.phone?.trim(),
        password: hashedPassword,
        role: "user",
        preferredCurrency: "NPR",
        isActive: true,
      });

    return {
      user: toPublicUser(createdUser),
      token:
        this.createToken(createdUser),
    };
  }

  async loginUser(
    data: LoginUserInput,
  ): Promise<{
    user: PublicUser;
    token: string;
  }> {
    const user =
      await userRepository
        .getUserByEmailWithPassword(
          data.email,
        );

    /*
     * Use one generic error so attackers cannot
     * determine whether an email exists.
     */
    if (!user) {
      throw new HttpError(
        401,
        "Invalid email or password",
      );
    }

    if (!user.isActive) {
      throw new HttpError(
        403,
        "This account has been disabled",
      );
    }

    const validPassword =
      await bcryptjs.compare(
        data.password,
        user.password,
      );

    if (!validPassword) {
      throw new HttpError(
        401,
        "Invalid email or password",
      );
    }

    return {
      user: toPublicUser(user),
      token: this.createToken(user),
    };
  }

  async getCurrentUser(
    userId: string,
  ): Promise<PublicUser> {
    const user =
      await userRepository.getUserById(
        userId,
      );

    if (!user) {
      throw new HttpError(
        404,
        "User account was not found",
      );
    }

    if (!user.isActive) {
      throw new HttpError(
        403,
        "This account has been disabled",
      );
    }

    return toPublicUser(user);
  }
}