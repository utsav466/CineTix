import bcryptjs from "bcryptjs";

import {
  connectDB,
  disconnectDB,
} from "../database/mongodb";

import {
  UserModel,
} from "../models/user.model";

async function createAdmin():
  Promise<void> {
  const [
    ,
    ,
    emailArgument,
    passwordArgument,
    nameArgument,
  ] = process.argv;

  if (
    !emailArgument ||
    !passwordArgument
  ) {
    console.error(
      "Usage: npm run create-admin -- admin@example.com Password123 \"Admin Name\"",
    );

    process.exitCode = 1;
    return;
  }

  if (
    passwordArgument.length < 8
  ) {
    console.error(
      "Admin password must contain at least 8 characters",
    );

    process.exitCode = 1;
    return;
  }

  const email =
    emailArgument
      .trim()
      .toLowerCase();

  const fullName =
    nameArgument?.trim() ||
    "CineTix Administrator";

  const existingUser =
    await UserModel.findOne({
      email,
    }).select("+password");

  const hashedPassword =
    await bcryptjs.hash(
      passwordArgument,
      12,
    );

  if (existingUser) {
    existingUser.fullName =
      fullName;

    existingUser.password =
      hashedPassword;

    existingUser.role =
      "admin";

    existingUser.isActive =
      true;

    await existingUser.save();

    console.log(
      `✅ Existing account updated as administrator: ${email}`,
    );

    return;
  }

  const usernameBase =
    email.split("@")[0]
      .replace(
        /[^a-z0-9._-]/g,
        "",
      )
      .slice(0, 20) ||
    "admin";

  let username =
    usernameBase;

  let counter = 1;

  while (
    await UserModel.exists({
      username,
    })
  ) {
    username =
      `${usernameBase}${counter}`;

    counter += 1;
  }

  await UserModel.create({
    fullName,
    email,
    username,
    password: hashedPassword,
    role: "admin",
    preferredCurrency: "NPR",
    avatarUrl: "",
    isActive: true,
  });

  console.log(
    `✅ Administrator created: ${email}`,
  );
}

async function run(): Promise<void> {
  try {
    await connectDB();
    await createAdmin();
  } catch (error) {
    console.error(
      "❌ Unable to create administrator:",
      error,
    );

    process.exitCode = 1;
  } finally {
    await disconnectDB();
  }
}

void run();