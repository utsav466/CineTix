import {
  NextFunction,
  Request,
  Response,
} from "express";

import mongoose from "mongoose";

import {
  CreateFoodSchema,
  UpdateFoodSchema,
} from "../dtos/food.dto";

import {
  HttpError,
} from "../errors/http-error";

import {
  FoodModel,
} from "../models/food.model";

function createSlug(
  name: string,
): string {
  return name
    .trim()
    .toLowerCase()
    .replace(
      /[^a-z0-9]+/g,
      "-",
    )
    .replace(
      /^-+|-+$/g,
      "",
    );
}

async function uniqueSlug(
  name: string,
  ignoredFoodId?: string,
): Promise<string> {
  const baseSlug =
    createSlug(name) || "food";

  let slug = baseSlug;
  let counter = 1;

  while (true) {
    const existing =
      await FoodModel.findOne({
        slug,
      });

    if (
      !existing ||
      existing._id.toString() ===
        ignoredFoodId
    ) {
      return slug;
    }

    slug =
      `${baseSlug}-${counter}`;

    counter += 1;
  }
}

function validateFoodId(
  id: string,
): void {
  if (
    !mongoose.Types.ObjectId
      .isValid(id)
  ) {
    throw new HttpError(
      400,
      "Invalid food ID",
    );
  }
}

export async function listFoods(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const query: Record<
      string,
      unknown
    > = {};

    if (
      req.query.available ===
      "true"
    ) {
      query.isAvailable =
        true;
    }

    if (
      typeof req.query
        .category ===
        "string" &&
      req.query.category
    ) {
      query.category =
        req.query.category;
    }

    if (
      typeof req.query.search ===
        "string" &&
      req.query.search.trim()
    ) {
      const search =
        req.query.search.trim();

      query.$or = [
        {
          name: {
            $regex: search,
            $options: "i",
          },
        },
        {
          description: {
            $regex: search,
            $options: "i",
          },
        },
      ];
    }

    const items =
      await FoodModel.find(query)
        .sort({
          isFeatured: -1,
          createdAt: -1,
        });

    res.status(200).json({
      success: true,
      data: {
        items,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getFood(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    validateFoodId(
      req.params.id,
    );

    const food =
      await FoodModel.findById(
        req.params.id,
      );

    if (!food) {
      throw new HttpError(
        404,
        "Food item was not found",
      );
    }

    res.status(200).json({
      success: true,
      data: {
        food,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function createFood(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const data =
      CreateFoodSchema.parse(
        req.body,
      );

    const slug =
      await uniqueSlug(
        data.name,
      );

    const food =
      await FoodModel.create({
        ...data,
        slug,
      });

    res.status(201).json({
      success: true,
      message:
        "Food item created successfully",
      data: {
        food,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function updateFood(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    validateFoodId(
      req.params.id,
    );

    const data =
      UpdateFoodSchema.parse(
        req.body,
      );

    const updateData: Record<
      string,
      unknown
    > = {
      ...data,
    };

    if (data.name) {
      updateData.slug =
        await uniqueSlug(
          data.name,
          req.params.id,
        );
    }

    const food =
      await FoodModel
        .findByIdAndUpdate(
          req.params.id,
          updateData,
          {
            new: true,
            runValidators: true,
          },
        );

    if (!food) {
      throw new HttpError(
        404,
        "Food item was not found",
      );
    }

    res.status(200).json({
      success: true,
      message:
        "Food item updated successfully",
      data: {
        food,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function deleteFood(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    validateFoodId(
      req.params.id,
    );

    const food =
      await FoodModel
        .findByIdAndDelete(
          req.params.id,
        );

    if (!food) {
      throw new HttpError(
        404,
        "Food item was not found",
      );
    }

    res.status(200).json({
      success: true,
      message:
        "Food item deleted successfully",
    });
  } catch (error) {
    next(error);
  }
}