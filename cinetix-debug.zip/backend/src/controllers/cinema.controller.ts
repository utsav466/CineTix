import mongoose from "mongoose";

import {
  NextFunction,
  Request,
  Response,
} from "express";

import {
  CreateCinemaSchema,
  UpdateCinemaSchema,
} from "../dtos/cinema.dto";

import {
  CinemaModel,
} from "../models/cinema.model";

import {
  ScreenModel,
} from "../models/screen.model";

import {
  HttpError,
} from "../errors/http-error";

function createSlug(
  name: string,
): string {
  return name
    .trim()
    .toLowerCase()
    .replace(
      /[^a-z0-9]+/g,
      "-",
    )
    .replace(
      /^-+|-+$/g,
      "",
    );
}

async function generateUniqueSlug(
  name: string,
  ignoredCinemaId?: string,
): Promise<string> {
  const baseSlug =
    createSlug(name) || "cinema";

  let slug = baseSlug;
  let counter = 1;

  while (true) {
    const existing =
      await CinemaModel.findOne({
        slug,
      });

    if (
      !existing ||
      existing._id.toString() ===
        ignoredCinemaId
    ) {
      return slug;
    }

    slug =
      `${baseSlug}-${counter}`;

    counter += 1;
  }
}

function validateCinemaId(
  id: string,
): void {
  if (
    !mongoose.Types.ObjectId.isValid(
      id,
    )
  ) {
    throw new HttpError(
      400,
      "Invalid cinema ID",
    );
  }
}

export async function listCinemas(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const query: Record<
      string,
      unknown
    > = {};

    if (
      req.query.active === "true"
    ) {
      query.isActive = true;
    }

    if (
      typeof req.query.city ===
        "string" &&
      req.query.city.trim()
    ) {
      query.city = {
        $regex:
          req.query.city.trim(),
        $options: "i",
      };
    }

    if (
      typeof req.query.search ===
        "string" &&
      req.query.search.trim()
    ) {
      const search =
        req.query.search.trim();

      query.$or = [
        {
          name: {
            $regex: search,
            $options: "i",
          },
        },
        {
          city: {
            $regex: search,
            $options: "i",
          },
        },
        {
          address: {
            $regex: search,
            $options: "i",
          },
        },
      ];
    }

    const cinemas =
      await CinemaModel.find(query)
        .sort({
          createdAt: -1,
        });

    const cinemaIds =
      cinemas.map(
        (cinema) => cinema._id,
      );

    const screenCounts =
      await ScreenModel.aggregate([
        {
          $match: {
            cinemaId: {
              $in: cinemaIds,
            },
          },
        },
        {
          $group: {
            _id: "$cinemaId",
            count: {
              $sum: 1,
            },
          },
        },
      ]);

    const countMap = new Map(
      screenCounts.map(
        (item) => [
          item._id.toString(),
          item.count,
        ],
      ),
    );

    const items =
      cinemas.map((cinema) => ({
        ...cinema.toJSON(),
        hallCount:
          countMap.get(
            cinema._id.toString(),
          ) || 0,
      }));

    res.status(200).json({
      success: true,
      data: {
        items,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getCinema(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    validateCinemaId(
      req.params.id,
    );

    const cinema =
      await CinemaModel.findById(
        req.params.id,
      );

    if (!cinema) {
      throw new HttpError(
        404,
        "Cinema was not found",
      );
    }

    const screens =
      await ScreenModel.find({
        cinemaId: cinema._id,
      }).sort({
        name: 1,
      });

    res.status(200).json({
      success: true,
      data: {
        cinema,
        screens,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function adminCreateCinema(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const data =
      CreateCinemaSchema.parse(
        req.body,
      );

    const slug =
      await generateUniqueSlug(
        data.name,
      );

    const cinema =
      await CinemaModel.create({
        ...data,
        slug,
      });

    res.status(201).json({
      success: true,
      message:
        "Cinema created successfully",
      data: {
        cinema,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function adminUpdateCinema(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    validateCinemaId(
      req.params.id,
    );

    const data =
      UpdateCinemaSchema.parse(
        req.body,
      );

    const updateData: Record<
      string,
      unknown
    > = {
      ...data,
    };

    if (data.name) {
      updateData.slug =
        await generateUniqueSlug(
          data.name,
          req.params.id,
        );
    }

    const cinema =
      await CinemaModel.findByIdAndUpdate(
        req.params.id,
        updateData,
        {
          new: true,
          runValidators: true,
        },
      );

    if (!cinema) {
      throw new HttpError(
        404,
        "Cinema was not found",
      );
    }

    res.status(200).json({
      success: true,
      message:
        "Cinema updated successfully",
      data: {
        cinema,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function adminDeleteCinema(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    validateCinemaId(
      req.params.id,
    );

    const hallCount =
      await ScreenModel.countDocuments({
        cinemaId: req.params.id,
      });

    if (hallCount > 0) {
      throw new HttpError(
        409,
        "Delete the cinema halls before deleting this cinema",
      );
    }

    const cinema =
      await CinemaModel.findByIdAndDelete(
        req.params.id,
      );

    if (!cinema) {
      throw new HttpError(
        404,
        "Cinema was not found",
      );
    }

    res.status(200).json({
      success: true,
      message:
        "Cinema deleted successfully",
    });
  } catch (error) {
    next(error);
  }
}