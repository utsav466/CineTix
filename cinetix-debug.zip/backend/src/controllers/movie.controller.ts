import {
  NextFunction,
  Request,
  Response,
} from "express";

import {
  CreateMovieSchema,
  UpdateMovieSchema,
} from "../dtos/movie.dto";

import {
  MovieStatus,
} from "../models/movie.model";

import {
  MovieService,
} from "../services/movie.service";

const movieService =
  new MovieService();

function parseBoolean(
  value: unknown,
): boolean | undefined {
  if (value === "true") {
    return true;
  }

  if (value === "false") {
    return false;
  }

  return undefined;
}

export async function listMovies(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const result =
      await movieService.listMovies({
        search:
          req.query.search as
            | string
            | undefined,

        genre:
          req.query.genre as
            | string
            | undefined,

        language:
          req.query.language as
            | string
            | undefined,

        status:
          req.query.status as
            | MovieStatus
            | undefined,

        featured:
          parseBoolean(
            req.query.featured,
          ),

        page:
          Number(
            req.query.page || 1,
          ),

        limit:
          Number(
            req.query.limit || 12,
          ),
      });

    res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    next(error);
  }
}

export async function getMovie(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const movie =
      await movieService.getMovieById(
        req.params.id,
      );

    res.status(200).json({
      success: true,
      data: {
        movie,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function adminListMovies(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  return listMovies(
    req,
    res,
    next,
  );
}

export async function adminGetMovie(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  return getMovie(
    req,
    res,
    next,
  );
}

export async function adminCreateMovie(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const parsedData =
      CreateMovieSchema.parse(
        req.body,
      );

    const movie =
      await movieService.createMovie(
        parsedData,
      );

    res.status(201).json({
      success: true,
      message:
        "Movie created successfully",
      data: {
        movie,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function adminUpdateMovie(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const parsedData =
      UpdateMovieSchema.parse(
        req.body,
      );

    const movie =
      await movieService.updateMovie(
        req.params.id,
        parsedData,
      );

    res.status(200).json({
      success: true,
      message:
        "Movie updated successfully",
      data: {
        movie,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function adminDeleteMovie(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    await movieService.deleteMovie(
      req.params.id,
    );

    res.status(200).json({
      success: true,
      message:
        "Movie deleted successfully",
    });
  } catch (error) {
    next(error);
  }
}

export async function adminMovieStatistics(
  _req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const statistics =
      await movieService
        .getMovieStatistics();

    res.status(200).json({
      success: true,
      data: statistics,
    });
  } catch (error) {
    next(error);
  }
}