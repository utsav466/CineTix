import {
  NextFunction,
  Request,
  Response,
} from "express";

import {
  env,
} from "../config";

import User from "../models/user.model";
import { generateToken } from "../utils/jwt";
import { AuthRequest } from "../middlewares/auth.middlewares";



type RegisterRequestBody = {
  fullName?: string;
  email?: string;
  phone?: string;
  password?: string;
  confirmPassword?: string;
};

type LoginRequestBody = {
  email?: string;
  password?: string;
  rememberMe?: boolean;
};

type RequestWithUser =
  Request & {
    user?: {
      userId: string;
      role: string;
    };
  };

function normalizeEmail(
  email: string,
): string {
  return email
    .trim()
    .toLowerCase();
}

function setAuthCookie(
  response: Response,
  token: string,
  rememberMe: boolean,
): void {
  const maximumAgeDays =
    rememberMe
      ? env.cookieMaxAgeDays
      : 1;

  response.cookie(
    env.cookieName,
    token,
    {
      httpOnly: true,

      secure:
        env.isProduction,

      sameSite:
        env.isProduction
          ? "none"
          : "lax",

      maxAge:
        maximumAgeDays *
        24 *
        60 *
        60 *
        1000,

      path: "/",
    },
  );
}

function clearAuthCookie(
  response: Response,
): void {
  response.clearCookie(
    env.cookieName,
    {
      httpOnly: true,

      secure:
        env.isProduction,

      sameSite:
        env.isProduction
          ? "none"
          : "lax",

      path: "/",
    },
  );
}

function serializeUser(
  user: {
    _id: {
      toString(): string;
    };

    fullName: string;
    email: string;
    phone: string;
    role: string;
    isActive: boolean;
  },
) {
  return {
    id:
      user._id.toString(),

    fullName:
      user.fullName,

    name:
      user.fullName,

    email:
      user.email,

    phone:
      user.phone,

    role:
      user.role,

    isActive:
      user.isActive,
  };
}

export async function register(
  request:
    Request<
      Record<string, never>,
      unknown,
      RegisterRequestBody
    >,
  response: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const {
      fullName,
      email,
      phone,
      password,
      confirmPassword,
    } =
      request.body;

    if (
      !fullName?.trim() ||
      !email?.trim() ||
      !phone?.trim() ||
      !password
    ) {
      response.status(400).json({
        success: false,

        message:
          "Full name, email, phone number and password are required.",
      });

      return;
    }

    if (
      password.length < 8
    ) {
      response.status(400).json({
        success: false,

        message:
          "Password must be at least 8 characters.",
      });

      return;
    }

    if (
      confirmPassword !==
      undefined &&
      password !==
        confirmPassword
    ) {
      response.status(400).json({
        success: false,

        message:
          "Passwords do not match.",
      });

      return;
    }

    const normalizedEmail =
      normalizeEmail(email);

    const existingUser =
      await User.findOne({
        email:
          normalizedEmail,
      });

    if (existingUser) {
      response.status(409).json({
        success: false,

        message:
          "An account with this email already exists.",
      });

      return;
    }

    const user =
      await User.create({
        fullName:
          fullName.trim(),

        email:
          normalizedEmail,

        phone:
          phone.trim(),

        password,

        role:
          "customer",

        isActive:
          true,
      });

    response.status(201).json({
      success: true,

      message:
        "Account created successfully.",

      data: {
        user:
          serializeUser(
            user,
          ),
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function login(
  request:
    Request<
      Record<string, never>,
      unknown,
      LoginRequestBody
    >,
  response: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const {
      email,
      password,
      rememberMe = false,
    } =
      request.body;

    if (
      !email?.trim() ||
      !password
    ) {
      response.status(400).json({
        success: false,

        message:
          "Email and password are required.",
      });

      return;
    }

    const normalizedEmail =
      normalizeEmail(email);

    const user =
      await User.findOne({
        email:
          normalizedEmail,
      }).select(
        "+password",
      );

    if (!user) {
      response.status(401).json({
        success: false,

        message:
          "Incorrect email or password.",
      });

      return;
    }

    if (!user.isActive) {
      response.status(403).json({
        success: false,

        message:
          "This account has been disabled.",
      });

      return;
    }

    const passwordMatches =
      await user.comparePassword(
        password,
      );

    if (!passwordMatches) {
      response.status(401).json({
        success: false,

        message:
          "Incorrect email or password.",
      });

      return;
    }

    const token =
      generateToken({
        userId:
          user._id.toString(),

        role:
          user.role,
      });

    setAuthCookie(
      response,
      token,
      Boolean(
        rememberMe,
      ),
    );

    response.status(200).json({
      success: true,

      message:
        "Signed in successfully.",

      data: {
        user:
          serializeUser(
            user,
          ),
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getMe(
  request: AuthRequest,
  response: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const userId =
      request.auth?.userId ||
      request.userId;

    if (!userId) {
      response.status(401).json({
        success: false,
        message:
          "Authentication is required",
      });

      return;
    }

    const user =
      await User.findById(
        userId,
      );

    if (!user) {
      clearAuthCookie(
        response,
      );

      response.status(401).json({
        success: false,
        message:
          "User account was not found",
      });

      return;
    }

    if (!user.isActive) {
      clearAuthCookie(
        response,
      );

      response.status(403).json({
        success: false,
        message:
          "This account has been disabled",
      });

      return;
    }

    response.status(200).json({
      success: true,

      data: {
        user: {
          id:
            user._id.toString(),

          fullName:
            user.fullName,

          name:
            user.fullName,

          email:
            user.email,

          phone:
            user.phone,

          role:
            user.role,

          isActive:
            user.isActive,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}
export function logout(
  _request: Request,
  response: Response,
): void {
  clearAuthCookie(
    response,
  );

  response.status(200).json({
    success: true,

    message:
      "Signed out successfully.",
  });
}