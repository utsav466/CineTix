import bcrypt from "bcryptjs";

import {
  HydratedDocument,
  Model,
  Schema,
  model,
  models,
} from "mongoose";

export type UserRole =
  | "customer"
  | "admin";

export interface IUser {
  fullName: string;
  email: string;
  phone: string;
  password: string;
  role: UserRole;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface IUserMethods {
  comparePassword(
    candidatePassword: string,
  ): Promise<boolean>;
}

export type UserDocument =
  HydratedDocument<
    IUser,
    IUserMethods
  >;

export type UserModelType =
  Model<
    IUser,
    Record<string, never>,
    IUserMethods
  >;

const userSchema =
  new Schema<
    IUser,
    UserModelType,
    IUserMethods
  >(
    {
      fullName: {
        type: String,
        required: [
          true,
          "Full name is required.",
        ],
        trim: true,
        minlength: 2,
        maxlength: 100,
      },

      email: {
        type: String,
        required: [
          true,
          "Email is required.",
        ],
        unique: true,
        trim: true,
        lowercase: true,
        index: true,
      },

      phone: {
        type: String,
        required: [
          true,
          "Phone number is required.",
        ],
        trim: true,
      },

      password: {
        type: String,
        required: [
          true,
          "Password is required.",
        ],
        minlength: 8,
        select: false,
      },

      role: {
        type: String,
        enum: [
          "customer",
          "admin",
        ],
        default: "customer",
      },

      isActive: {
        type: Boolean,
        default: true,
      },
    },
    {
      timestamps: true,

      toJSON: {
        transform(
          _document,
          returnedObject,
        ) {
          const safeObject =
            returnedObject as Record<
              string,
              unknown
            >;

          delete safeObject.password;
          delete safeObject.__v;

          return safeObject;
        },
      },

      toObject: {
        transform(
          _document,
          returnedObject,
        ) {
          const safeObject =
            returnedObject as Record<
              string,
              unknown
            >;

          delete safeObject.password;
          delete safeObject.__v;

          return safeObject;
        },
      },
    },
  );

userSchema.pre(
  "save",
  async function hashPassword() {
    if (
      !this.isModified(
        "password",
      )
    ) {
      return;
    }

    const salt =
      await bcrypt.genSalt(
        12,
      );

    this.password =
      await bcrypt.hash(
        this.password,
        salt,
      );
  },
);

userSchema.methods.comparePassword =
  async function comparePassword(
    candidatePassword: string,
  ): Promise<boolean> {
    return bcrypt.compare(
      candidatePassword,
      this.password,
    );
  };

export const UserModel =
  (models.User as UserModelType) ||
  model<
    IUser,
    UserModelType
  >(
    "User",
    userSchema,
  );

export const User =
  UserModel;

export default UserModel;