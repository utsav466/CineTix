import {
  Router,
} from "express";

import {
  adminCreateMovie,
  adminDeleteMovie,
  adminGetMovie,
  adminListMovies,
  adminMovieStatistics,
  adminUpdateMovie,
} from "../controllers/movie.controller";

import {
  requireAdmin,
} from "../middlewares/admin.middleware";

import {
  requireAuth,
} from "../middlewares/auth.middlewares";

const router = Router();

router.use(
  requireAuth,
  requireAdmin,
);

router.get(
  "/statistics",
  adminMovieStatistics,
);

router.get(
  "/",
  adminListMovies,
);

router.post(
  "/",
  adminCreateMovie,
);

router.get(
  "/:id",
  adminGetMovie,
);

router.patch(
  "/:id",
  adminUpdateMovie,
);

router.delete(
  "/:id",
  adminDeleteMovie,
);

export default router;