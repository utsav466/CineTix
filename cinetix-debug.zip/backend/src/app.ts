import cookieParser from "cookie-parser";
import cors from "cors";
import express, {
  NextFunction,
  Request,
  Response,
} from "express";
import helmet from "helmet";

import {
  env,
} from "./config";

import authRoutes from "./routes/auth.route";
import movieRoutes from "./routes/movie.route";
import cinemaRoutes from "./routes/cinema.route";
import screenRoutes from "./routes/screen.route";
import showtimeRoutes from "./routes/showtime.route";
import bookingRoutes from "./routes/booking.route";
import foodRoutes from "./routes/food.route";
import couponRoutes from "./routes/coupon.route";
import paymentRoutes from "./routes/payment.route";
import morgan from "morgan";

const app =
  express();

app.disable(
  "x-powered-by",
);

app.use(
  helmet({
    crossOriginResourcePolicy: {
      policy:
        "cross-origin",
    },
  }),
);

app.use(
  cors({
    origin(
      requestOrigin,
      callback,
    ) {
      const allowedOrigins = [
        env.frontendUrl,
        "http://localhost:3000",
        "http://127.0.0.1:3000",
      ];

      if (
        !requestOrigin ||
        allowedOrigins.includes(
          requestOrigin,
        )
      ) {
        callback(
          null,
          true,
        );

        return;
      }

      callback(
        new Error(
          `CORS blocked origin: ${requestOrigin}`,
        ),
      );
    },

    credentials:
      true,

    methods: [
      "GET",
      "POST",
      "PUT",
      "PATCH",
      "DELETE",
      "OPTIONS",
    ],

    allowedHeaders: [
      "Content-Type",
      "Authorization",
    ],
  }),
);

app.use(
  express.json({
    limit: "10mb",
  }),
);

app.use(
  express.urlencoded({
    extended: true,
    limit: "10mb",
  }),
);

app.use(
  cookieParser(),
);

if (
  env.isDevelopment
) {
  app.use(
    morgan("dev"),
  );
}

app.get(
  "/",
  (
    _request:
      Request,
    response:
      Response,
  ) => {
    response.status(200).json({
      success: true,
      message:
        "CineTix API is running.",
    });
  },
);

app.get(
  "/api/health",
  (
    _request:
      Request,
    response:
      Response,
  ) => {
    response.status(200).json({
      success: true,

      data: {
        service:
          "CineTix API",

        status:
          "healthy",

        environment:
          env.nodeEnv,

        timestamp:
          new Date().toISOString(),
      },
    });
  },
);

app.use(
  "/api/auth",
  authRoutes,
);

app.use(
  "/api/movies",
  movieRoutes,
);

app.use(
  "/api/cinemas",
  cinemaRoutes,
);

app.use(
  "/api/screens",
  screenRoutes,
);

app.use(
  "/api/showtimes",
  showtimeRoutes,
);

app.use(
  "/api/bookings",
  bookingRoutes,
);

app.use(
  "/api/foods",
  foodRoutes,
);

app.use(
  "/api/coupons",
  couponRoutes,
);

app.use(
  "/api/payments",
  paymentRoutes,
);

app.use(
  (
    request:
      Request,
    response:
      Response,
  ) => {
    response.status(404).json({
      success: false,

      message:
        `Route not found: ${request.method} ${request.originalUrl}`,
    });
  },
);

app.use(
  (
    error: unknown,
    _request:
      Request,
    response:
      Response,
    _next:
      NextFunction,
  ) => {
    const message =
      error instanceof Error
        ? error.message
        : "Internal server error";

    console.error(
      "Express error:",
      error,
    );

    response.status(500).json({
      success: false,

      message:
        env.isProduction
          ? "Internal server error"
          : message,
    });
  },
);

export default app;