import {
  IUser,
  UserModel,
} from "../models/user.model";

export type CreateUserRecord = {
  fullName: string;
  email: string;
  username: string;
  phone?: string;
  password: string;
  role?: "user" | "admin";
  preferredCurrency?: "NPR" | "USD" | "INR";
  avatarUrl?: string;
  isActive?: boolean;
};

export class UserRepository {
  async createUser(
    data: CreateUserRecord,
  ): Promise<IUser> {
    return UserModel.create(data);
  }

  async getUserById(
    id: string,
  ): Promise<IUser | null> {
    return UserModel.findById(id);
  }

  async getUserByIdWithPassword(
    id: string,
  ): Promise<IUser | null> {
    return UserModel.findById(id).select(
      "+password",
    );
  }

  async getUserByEmail(
    email: string,
  ): Promise<IUser | null> {
    return UserModel.findOne({
      email: email.trim().toLowerCase(),
    });
  }

  async getUserByEmailWithPassword(
    email: string,
  ): Promise<IUser | null> {
    return UserModel.findOne({
      email: email.trim().toLowerCase(),
    }).select("+password");
  }

  async getUserByUsername(
    username: string,
  ): Promise<IUser | null> {
    return UserModel.findOne({
      username:
        username.trim().toLowerCase(),
    });
  }

  async getUserByResetToken(
    hashedToken: string,
  ): Promise<IUser | null> {
    return UserModel.findOne({
      resetPasswordToken: hashedToken,

      resetPasswordExpires: {
        $gt: new Date(),
      },
    }).select(
      "+password +resetPasswordToken +resetPasswordExpires",
    );
  }

  async updateUser(
    id: string,
    data: Partial<IUser>,
  ): Promise<IUser | null> {
    return UserModel.findByIdAndUpdate(
      id,
      data,
      {
        new: true,
        runValidators: true,
      },
    );
  }

  async deleteUser(
    id: string,
  ): Promise<IUser | null> {
    return UserModel.findByIdAndDelete(id);
  }

  async getAllUsers(
    page = 1,
    limit = 10,
    search = "",
  ): Promise<{
    users: IUser[];
    total: number;
  }> {
    const safePage = Math.max(page, 1);

    const safeLimit = Math.min(
      Math.max(limit, 1),
      100,
    );

    const skip =
      (safePage - 1) * safeLimit;

    const query: Record<string, unknown> =
      {};

    if (search.trim()) {
      query.$or = [
        {
          fullName: {
            $regex: search.trim(),
            $options: "i",
          },
        },
        {
          email: {
            $regex: search.trim(),
            $options: "i",
          },
        },
        {
          username: {
            $regex: search.trim(),
            $options: "i",
          },
        },
      ];
    }

    const [users, total] =
      await Promise.all([
        UserModel.find(query)
          .sort({
            createdAt: -1,
          })
          .skip(skip)
          .limit(safeLimit),

        UserModel.countDocuments(query),
      ]);

    return {
      users,
      total,
    };
  }
}