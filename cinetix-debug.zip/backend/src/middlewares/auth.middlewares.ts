import {
  NextFunction,
  Request,
  Response,
} from "express";

import {
  env,
} from "../config";

import {
  verifyToken,
} from "../utils/jwt";

export type AuthPayload = {
  userId: string;
  role: string;
};

export interface AuthRequest
  extends Request {
  /**
   * Older controllers use:
   * req.userId
   */
  userId?: string;

  /**
   * Some controllers may use:
   * req.role
   */
  role?: string;

  /**
   * Newer controllers and admin middleware use:
   * req.auth.userId
   */
  auth?: AuthPayload;
}

function getBearerToken(
  request: Request,
): string | undefined {
  const authorization =
    request.headers.authorization;

  if (
    !authorization ||
    !authorization.startsWith(
      "Bearer ",
    )
  ) {
    return undefined;
  }

  const token =
    authorization
      .slice(7)
      .trim();

  return token || undefined;
}

export function requireAuth(
  request: AuthRequest,
  response: Response,
  next: NextFunction,
): void {
  try {
    const cookieToken =
      request.cookies?.[
        env.cookieName
      ] as
        | string
        | undefined;

    const bearerToken =
      getBearerToken(
        request,
      );

    const token =
      cookieToken ||
      bearerToken;

    if (!token) {
      response.status(401).json({
        success: false,
        message:
          "Authentication is required",
      });

      return;
    }

    const payload =
      verifyToken(token);

    /*
     * Support all existing controllers.
     */
    request.userId =
      payload.userId;

    request.role =
      payload.role;

    request.auth = {
      userId:
        payload.userId,

      role:
        payload.role,
    };

    next();
  } catch {
    response.status(401).json({
      success: false,
      message:
        "Your session is invalid or has expired",
    });
  }
}